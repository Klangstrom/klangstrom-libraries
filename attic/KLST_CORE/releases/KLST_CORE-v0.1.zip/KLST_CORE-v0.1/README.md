# KLST_CORE-v0.1

note that this is not the original v0.1 release anymore. it contains already a fix [swapped USB for DFU mode, swapped pins on 5/12V power switch](https://github.com/interaktion-und-raum/klangstrom/commit/7c3df3893bf12d65c3c148f6bf7789e79af76e37)